const generos = ['Ciencia Ficción', 'Drama', 'Suceso Real', 'Suspenso', 'Fantasía', 'Familia', 'Acción', 'Terror', 'Aventura']
const URL = '../trailerflix.json'
let contenido;
let armoHTML;